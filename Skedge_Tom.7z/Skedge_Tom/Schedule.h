#ifndef _SCHEDULE_H_ //inclusion guard
#define _SCHEDULE_H_
#include <string>
#include <vector>
#include "Events.h"

using namespace std;

class Schedule {
private:
	vector <Events> events; //vector for events
	vector <string> users;//vector for users
	vector <string> passwords;
	int numUsers;//number of users
public:
	Schedule();//no argument constructor
	void create_event(DateTime eventdate, string user, string eventname, vector <string> buddy); //creates new event
	void output_Calendar(string user); //outputs calendar in new file
	void delete_event(string eventname, string user);//deletes event
	int getNumEvents(string user);//gets number of events
	bool isCorrectPassword(string user, string password);//checks if password is correct
	void newUser(string user, string password);//creates  new user
};
#endif