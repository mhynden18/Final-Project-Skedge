#ifndef DATE
#define DATE
using namespace std;
#include <string>
class DateTime
{
private:
	int minute;
	int hour;
	int day;
	int month;
public:
	DateTime();//only no argument constructor is needed because account should always refrence current time found from "ctime.h"
	DateTime(int eventmonth, int eventday, int eventhour, int eventminute);
	//getter functions to return object properties year month and day
	int get_month();
	int get_day();
	int get_hour();
	int get_minute();
};

#endif