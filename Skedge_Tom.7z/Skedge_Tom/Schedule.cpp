///////////////////////////
//Schedule part of Skedge
//////////////////////////

#include "Schedule.h"
#include <iostream>
#include <string>
#include <vector>
#include "Events.h"

Schedule::Schedule()//no argument constructor
{
	events.clear(); //vector for events
	users.clear();//vector for users
	passwords.clear();
	DateTime now;
	Events blah(now, "", "");
	events.push_back(blah);
	users.push_back("");//makes a user and password of name blank so that no one can make new user
	passwords.push_back("");
	numUsers = 1;//one intitial user of name ""
}

void Schedule::create_event(DateTime eventdate, string user, string eventname, vector <string> friends)//creates an event with time frineds and description
{
	Events newevent(eventdate, eventname, user);
	events.push_back(newevent);//creates event for the user
	for (int i = 0; (i) < friends.size();i++)
	{
		Events newevent(eventdate, eventname, friends[i]);
		events.push_back(newevent);//creates event for each friend
	}
}//possibly make into create_myevents and create_friendsevents

void Schedule::output_Calendar(string user)
{
}

void Schedule::delete_event(string eventname, string user)
{
}

int Schedule::getNumEvents(string user)//gets number of events that the user has
{
	int numEvents = 0; //variable counting events that belong to this user
	for (int i = 0; i < events.size(); i++)
	{
		if (user == events[i].get_user())
		{
			numEvents++;//if user is the same as the user for the event add one to the number of events
		}
	}
	return numEvents;//returns number of events
}

bool Schedule::isCorrectPassword(string user, string password)
{
	int userNumber = 0;//correlating number to user position in vector
	for (int i = 0; i < numUsers; i++)//find number associated with user
	{
		if (user == users.at(i))
		{
			userNumber = i;
		}
	}
	if (userNumber == 0) return false;
	if (passwords.at(userNumber) == password) return true;
	else return false;
	//compare given password to the password saved for that user
}

void Schedule::newUser(string user, string password)
{
	numUsers++;
	users.push_back(user);//add 1 user to users vector,
	passwords.push_back(password);//add 1 password to password vector
}
