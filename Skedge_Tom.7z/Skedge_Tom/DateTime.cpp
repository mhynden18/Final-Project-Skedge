#include "ctime"
using namespace std;
#include <iostream>
#include "DateTime.h"
DateTime::DateTime()//gets current month, day, year
{
	time_t now = time(0);//make variable now equal to current seconds since 1970
	tm *ltm = localtime(&now);//creates tm object found in the ctime library

	month = 1 + ltm->tm_mon;//sets month
	day = ltm->tm_mday;//sets day
	hour = ltm->tm_hour;
	minute = ltm->tm_min;
}
DateTime::DateTime(int eventmonth, int eventday, int eventhour, int eventminute)
{
	month = eventmonth;
	day = eventday;
	hour = eventhour;
	minute = eventminute;
}

int DateTime::get_month()
{
	return month;
}

int DateTime::get_day()
{
	return day;
}

int DateTime::get_hour()
{
	return hour;
}

int DateTime::get_minute()
{
	return minute;
}

