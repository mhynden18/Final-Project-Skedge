#include "Events.h"


Events::Events(DateTime eventTime, string eventname, string User)//called by schedule.cpp to create a new event
{
	datetime = eventTime;
	this->eventname = eventname;
	this->User = User;

}

DateTime Events::get_datetime()//getters
{
	return datetime;
}

string Events::get_eventname()
{
	return eventname;
}

string Events::get_user()
{
	return User;
}

