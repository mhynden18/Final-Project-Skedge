#include "ctime"
using namespace std;
#include <iostream>
#include "DateTime.h"
DateTime::DateTime()//gets current month, day, year
{
}
DateTime::DateTime(int eventmonth, int eventday, int eventhour, int eventminute)
{
	month = eventmonth;
	day = eventday;
	hour = eventhour;
	minute = eventminute;
}

void DateTime::set(int eventmonth, int eventday, int eventhour, int eventminute)
{
	month = eventmonth;
	day = eventday;
	hour = eventhour;
	minute = eventminute;
}

int DateTime::get_month()
{
	return month;
}

int DateTime::get_day()
{
	return day;
}

int DateTime::get_hour()
{
	return hour;
}

int DateTime::get_minute()
{
	return minute;
}
