//skedge app

#include <iostream>
#include "Events.h"
#include "DateTime.h"
#include "Schedule.h"
#include <vector>
#include <string>
#include <ctime>
using namespace std;


int main()
{
		Schedule testProgram;//make object testProgram to hold users passwords and events
		string user;//variable for user to enter his name
		string password;//vaible for user to enter password
		string eventname;//string to name event
		string friendname;//string to represent a specific users added to an event
		vector <string> friends;//vector holding all friends added to an event
		int numpeople;//number of friends joining user for event
		int eventmonth;
		int eventday;
		int eventhour;
		int eventminute;
		int control; //int value for user defined navigation
		DateTime eventdate;
	while (true)//always running because app is always open
	{

		
		do{
			cout << "Welcome to Skedge!" << endl;
			do{//loops if user tries to enter values other than 1 or 2
				cout << "To login press 1, for new user press 2.";
				cin >> control;
			}while (control != 1 && control != 2);

			cout << "Enter Username: ";
			cin >> user;
			cout << "Enter Password: ";
			cin >> password;
			if (control == 2){//if new user is selected create new user and login
				testProgram.newUser(user, password);
				break;
			}
			if (testProgram.isCorrectPassword(user, password) == false) cout << "Incorrect password" << endl << endl;
		} while (testProgram.isCorrectPassword(user, password) == false);//require repeated login if incorrect

		
			bool repeat =true;//variable to repeats schedule menu navigation
			do{//schedule menu
				cout << "You have " << testProgram.getNumEvents(user) << " upcoming events." << endl;
				cout << "Would you like to:" << endl << "1 create an event" << endl << "2 delete an event" << endl << "3 print your Skedge" << endl << "or 4 Logout? ";
				cin >> control;
				switch (control)
				{
				case 1://creates event
					cout << "What is the event?" << endl;
					cin >> eventname;
					cout << "What is the date of your event (Format: month day) ?" << endl;
					cin >> eventmonth >> eventday;
					cout << "What is the time of your event (Format: hour minute) ?" << endl;
					cin >> eventhour >> eventminute;
					cout << "How many people will be going to this event?" << endl;
					cin >> numpeople;
					if (numpeople != 0) cout << "What are their Skedge usernames?" << endl;
					for (int i = 0; i < numpeople; i++)
					{
						cin >> friendname;
						friends.push_back(friendname);
					}
					eventdate.set(eventmonth, eventday, eventhour, eventminute);//make new datetime variable for the event
					testProgram.create_event(eventdate, user, eventname, friends);// make new event
					cout << eventname << " has been created";
					break;
				case 2://deletes event
					cout << "What is the title of the event you want to delete? ";
					cin >> eventname;
					testProgram.delete_event(eventname, user);
					break;
				case 3://prints Skedge file
					testProgram.output_Calendar(user);
					break;
				case 4://logout
					cout << "Goodbye " << user << "!!!" << endl << endl;
					repeat = false;
					break;
				}
				cout << endl << endl;
			} while (repeat == true);









	}
}