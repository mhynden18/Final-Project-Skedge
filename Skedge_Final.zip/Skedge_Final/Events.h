#ifndef EVENT
#define EVENT

using namespace std;
#include <string>
#include <vector>
#include "DateTime.h"

class Events
{
private:
	DateTime datetime;
	string eventname;
	string User;
public:
	Events(DateTime eventTime, string eventname, string User);
	DateTime get_datetime();
	string get_eventname();
	string get_user();

};
#endif