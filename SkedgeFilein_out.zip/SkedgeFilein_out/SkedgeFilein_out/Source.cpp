#include <iostream>
#include <string>
#include <fstream>

using namespace std;
int main()

{
	ofstream fout;
	fout.open("Skedge.txt");

	if (fout.fail()) {
		cout << "can't open file" << endl;
		return 0;
	}

	int i = 1;
	while (0 < i)
	{
		cout << event[i].eventname; 
	}
	
	fout.close();
}